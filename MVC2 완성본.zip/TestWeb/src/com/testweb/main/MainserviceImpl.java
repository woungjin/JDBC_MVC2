package com.testweb.main;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.testweb.bbs.model.BbsDAO;
import com.testweb.bbs.model.BbsVO;

public class MainserviceImpl implements MainService {


	public void execute(HttpServletRequest request, HttpServletResponse response) {
		BbsDAO dao = BbsDAO.getInstance();
		ArrayList<BbsVO> list =dao.mainList(); 
		
		System.out.println("�Ǥ�");
		
		request.setAttribute("list", list);

	}

}
