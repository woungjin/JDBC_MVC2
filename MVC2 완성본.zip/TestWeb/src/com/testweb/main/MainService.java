package com.testweb.main;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface MainService{
	
	public void execute(HttpServletRequest request, HttpServletResponse response);
	

}
