package com.testweb.user.model;

import java.sql.Connection;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.testweb.user.model.UserDAO;
import com.testweb.user.model.UserVO;
import com.testweb.util.JdbcUtil;

public class UserDAO {

	private static UserDAO instance = new UserDAO();
	private DataSource ds;
	
	private UserDAO() {
		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//		 	Ŀ�ؼ� Ǯ 
			InitialContext ct = new InitialContext();
			ds =(DataSource)ct.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static UserDAO getInstance() {
		return instance;
	}
	
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	public int check_id(String id) {
		int result = 0;
		String sql = "select * from users where id = ? ";

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();
 
			if (rs.next()) {
				result = 1; // id ����� 1
			} else {
				result = 0; // ������ 0
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return result;
	}

	public int join(UserVO vo) {

		int result = 0; // ����� ��ȯ
		String sql = "insert into users(id,pw,name,email,address,phone) values(?,?,?,?,?,?)";

		try {
			conn = ds.getConnection();

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPw());
			pstmt.setString(3, vo.getName());
			pstmt.setString(4, vo.getEmail());
			pstmt.setString(5, vo.getAddress());
			pstmt.setString(6, vo.getPhone());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}

		return result;
	}

	
	
	public UserVO login(String id, String pw) {

		String sql = "select * from users where id = ? and pw = ?";
		UserVO u = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				u = new UserVO();
				u.setId(rs.getString("id"));
				u.setName(rs.getString("name"));
				u.setEmail(rs.getString("email"));
				u.setAddress(rs.getString("address"));
				u.setPhone(rs.getString("phone"));
				u.setRegdate(rs.getTimestamp("regdate"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return u;

	}

	public int update(UserVO vo) {
		String sql  = "update users set pw=? ,name=?,email=?,address=?,phone=? where id=?";
		int result = 0 ;
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getPw() );
			pstmt.setString(2, vo.getName());
			pstmt.setString(3, vo.getEmail());
			pstmt.setString(4, vo.getAddress());
			pstmt.setString(5, vo.getPhone());
			pstmt.setString(6, vo.getId());
			
			 result = pstmt.executeUpdate(); 
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
			
		}
		return result;
	}
	

	public int delete(String id) {
		
		String sql = "delete users where id = ?";
		int res = 0 ;
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			res = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return res;
	}
	
	public UserVO login(String id) {

		String sql = "select * from users where id = ?";
		UserVO u = null;

		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				u = new UserVO();
				u.setId(rs.getString("id"));
				u.setName(rs.getString("name"));
				u.setEmail(rs.getString("email"));
				u.setAddress(rs.getString("address"));
				u.setPhone(rs.getString("phone"));
				u.setRegdate(rs.getTimestamp("regdate"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return u;

	}
}
