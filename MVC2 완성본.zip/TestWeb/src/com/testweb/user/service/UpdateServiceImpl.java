package com.testweb.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.testweb.user.model.UserDAO;
import com.testweb.user.model.UserVO;

public class UpdateServiceImpl implements UserServiceImpl{

	
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
			String id = request.getParameter("id");
			String pw = request.getParameter("password");
			String name = request.getParameter("name");
			String email = request.getParameter("email") + "@" +request.getParameter("email_check");
			String address= request.getParameter("address-basic") + "," + request.getParameter("address-detail");
			String phone = request.getParameter("phone1") + "-"+ request.getParameter("phone2") + "-" + request.getParameter("phone3");

			UserVO user = new UserVO(id, pw, name, email, address, phone, null);
			System.out.println("id : " + id + " pw : " + pw + " phone = " + phone + " name : " + name + " email :" + email  );
			UserDAO dao = UserDAO.getInstance();
			int result = dao.update(user);
			

			HttpSession session = request.getSession();
			String arremail[] = email.split("@");
			user.setEmail(arremail[0]);
			
			session.setAttribute("user", user);

			
		return result;
	}
}
