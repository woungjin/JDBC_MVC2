package com.testweb.user.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.testweb.bbs.model.BbsDAO;
import com.testweb.bbs.model.BbsVO;
import com.testweb.user.model.UserVO;
import com.testweb.util.PageVO;

public class GetListBbsServiceImpl implements UserServiceImpl {
		
	

	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		BbsDAO dao = BbsDAO.getInstance();
			
		HttpSession session = request.getSession();
		UserVO user = (UserVO) session.getAttribute("user");
		String id = user.getId();
		
		ArrayList<BbsVO> list = dao.getListuser(id);
		request.setAttribute("list", list);
		
		return 1;
	}
}
