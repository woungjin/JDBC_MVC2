package com.testweb.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.testweb.user.model.UserDAO;
import com.testweb.user.model.UserVO;

public class UserLoginServiceImpl implements UserServiceImpl {

		
		public int execute(HttpServletRequest request, HttpServletResponse response) {
			
			UserDAO dao = UserDAO.getInstance();
			String id = request.getParameter("id");
			String pw = request.getParameter("password");
			
			UserVO user = dao.login(id,pw);
			
			if(user == null) {
				return 0;
			} else { // user��ü�� �����ϸ� ���ǿ� ������ ����
				HttpSession session = request.getSession();
				String email = user.getEmail();
				String arremail[] = email.split("@");
				user.setEmail(arremail[0]);
				
				session.setAttribute("user", user);

				return 1;
			}
		}
	
}
