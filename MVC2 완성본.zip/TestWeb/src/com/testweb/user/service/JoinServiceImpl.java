package com.testweb.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.testweb.user.model.UserDAO;
import com.testweb.user.model.UserVO;

public class JoinServiceImpl implements UserServiceImpl {
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {

		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		String name = request.getParameter("name");
		String email = request.getParameter("email")+ "@" +request.getParameter("email_check") ;
		String phone = request.getParameter("phone1") + "-" + request.getParameter("phone2") + "-" + request.getParameter("phone3");
		
		String address = request.getParameter("addr-basic") + ","+ request.getParameter("addr-detail");
		
		System.out.println(email);
		UserDAO dao = UserDAO.getInstance();
		int result = dao.check_id(id);
		if (result == 1) { // �����ϴ� id�� �ִٸ�
			return 1;
		} else { // id ����
			UserVO vo = new UserVO(id, pw, name, email , address,phone, null);
			
			dao.join(vo);
			return 0 ;
		}

	}
}
