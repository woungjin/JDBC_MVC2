package com.testweb.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.testweb.bbs.service.BbsService;
import com.testweb.bbs.service.ContentServiceImpl;
import com.testweb.bbs.service.DeleteServiceImpl;
import com.testweb.bbs.service.GetListBbsServiceImpl;
import com.testweb.bbs.service.RegistServiceImpl;
import com.testweb.bbs.service.UpdateServiceImpl;

@WebServlet("*.board")
public class BbsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	public BbsController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		dispatchServlet(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		dispatchServlet(request, response);
	}

	private void dispatchServlet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String command = uri.substring(conPath.length());
		
		BbsService service ;
		
		if(command.equals("/bbs/list.board")) { // �Խ��� ��ϵ�
			service = new GetListBbsServiceImpl();
			service.execute(request, response);
	
			request.getRequestDispatcher("bbs_list.jsp").forward(request, response);
			
		} else if (command.equals("/bbs/write.board")) {
			request.getRequestDispatcher("bbs_write.jsp").forward(request, response);
		} else if (command.equals("/bbs/regist.board")) {
			service = new RegistServiceImpl();
			service.execute(request, response);
			System.out.println("��ϼ���");		
			response.sendRedirect("list.board");
		} else if (command.equals("/bbs/content.board")) {
			service = new ContentServiceImpl();
			service.execute(request, response);
			
			request.getRequestDispatcher("bbs_content.jsp").forward(request, response);
		} else if (command.equals("/bbs/modify.board")) {
			service = new ContentServiceImpl();
			service.execute(request, response);
			
			request.getRequestDispatcher("bbs_modify.jsp").forward(request, response);
		} else if (command.equals("/bbs/update.board")) {
			service = new UpdateServiceImpl();
			service.execute(request, response);
			
			request.getRequestDispatcher("content.board").forward(request, response);
//			response.sendRedirect("content.board?bno=" + request.getParameter("bno"));
		} else if (command.equals("/bbs/delete.board")) {
			service = new DeleteServiceImpl();
			service.execute(request,response);
			
			response.sendRedirect("list.board");
		}
 				
		
	}

}
