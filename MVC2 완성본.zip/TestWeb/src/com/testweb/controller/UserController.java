package com.testweb.controller;

import java.io.IOException; 
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.testweb.user.service.GetListBbsServiceImpl;
import com.testweb.user.service.JoinServiceImpl;
import com.testweb.user.service.UpdateServiceImpl;
import com.testweb.user.service.UserDeleteServiceImpl;
import com.testweb.user.service.UserLoginServiceImpl;
import com.testweb.user.service.UserServiceImpl;

@WebServlet("*.user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		dispatchServlet(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		dispatchServlet(request, response);
	}

	protected void dispatchServlet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String command = uri.substring(conPath.length());
		
		UserServiceImpl service;
		
		if(command.equals("/user/join.user")) {
			request.getRequestDispatcher("user_join.jsp").forward(request, response);;
		} else if (command.equals("/user/joinForm.user")) {
			service = new JoinServiceImpl();
			int result = service.execute(request, response);
			
			if(result == 1) { // ȸ������ ���н�
				request.setAttribute("message" , "�̹� �����ϴ� ȸ���Դϴ�.");
				request.getRequestDispatcher("user_join.jsp").forward(request, response);
			} else {
				response.sendRedirect("user_login.jsp");
			}
		} else if (command.equals("/user/login.user")) {
			request.getRequestDispatcher("user_login.jsp").forward(request, response);
		} else if (command.equals("/user/loginForm.user")) {
			service = new UserLoginServiceImpl();
			int result = service.execute(request, response);
			
			if(result == 0) { // �α��� ������
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('���̵�� ��й�ȣ�� Ȯ�����ּ���');");
				out.println("location.href='login.user';");
				out.println("</script>");
			
			} else {
				response.sendRedirect("mypage.user");
			}
		} else if(command.equals("/user/mypage.user")) {
			service = new GetListBbsServiceImpl();
			int result = service.execute(request, response);
			
			if( result != 0) {
				request.getRequestDispatcher("user_mypage.jsp").forward(request, response);
			} else {
				response.sendRedirect(request.getContextPath());
			}
		} else if (command.equals("/user/update.user")) {
			request.getRequestDispatcher("user_mypageinfo.jsp").forward(request, response);
		} else if (command.equals("/user/updateForm.user")) {
	
			service = new UpdateServiceImpl() ;
			int result = service.execute(request, response);
			
			if(result == 1) { // ���� �Ϸ��
				
				request.getRequestDispatcher("mypage.user").forward(request, response);
			
			} else {
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('ȸ������ ���� ����');");
				out.println("location.href='mypage.user';");
				out.println("</script>");
			
			}
			
		}  else if (command.equals("/user/deleteForm.user")) {
			service = new UserDeleteServiceImpl();
			int result = service.execute(request, response);
			
			if(result==1) { //���� ������
				 response.sendRedirect(request.getContextPath());
			} else {
				request.setAttribute("message", "��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
				request.getRequestDispatcher("user_mypage.jsp").forward(request, response);
			}
					
			
		} else if (command.equals("/user/logout.user")) {
			HttpSession session = request.getSession();
			session.invalidate();
			
			response.sendRedirect(request.getContextPath());
		}
		
		
		
	}

}
