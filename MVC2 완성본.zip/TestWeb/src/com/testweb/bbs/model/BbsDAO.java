package com.testweb.bbs.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.testweb.util.JdbcUtil;

public class BbsDAO {

	
	private static BbsDAO instance = new BbsDAO();
	private DataSource ds ;
	
	private BbsDAO () {
		try {
			InitialContext ct = new InitialContext();
			ds =(DataSource) ct.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
	}
	
	public static BbsDAO getInstance() {
		return instance;
	}
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	
	public void regist(String writer , String title, String content) {
		String sql = "insert into board(bno,writer,title,content) values(board_seq.nextval,?,?,?)";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, writer );
			pstmt.setString(2, title);
			pstmt.setString(3, content);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
	}
	
	public BbsVO getConent(String bno) {
		String sql = "select * from board where bno = ?";
		BbsVO vo = new BbsVO();
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bno);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				vo.setBno(rs.getInt("bno"));
				vo.setContent(rs.getString("content"));
				vo.setWriter(rs.getString("writer"));
				vo.setTitle(rs.getString("title"));
				vo.setHit(rs.getInt("hit"));
				vo.setRegdate(rs.getTimestamp("regdate"));
			}
			
		} catch (Exception e) {
				e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		} 
		return vo;
	}
	
	public void update(String bno , String title, String content) {
		String sql = "update board set title=? , content=? where bno = ? ";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setString(3, bno);
			
			pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
	}
	
	public	ArrayList<BbsVO> getList(int pageNum, int amount) {
		ArrayList<BbsVO> list = new ArrayList<>();
		
		String sql = "select *\r\n" + 
				"from (select rownum rn, bno,writer,title,content,regdate,hit \r\n" + 
				"    from (select * from board order by bno desc)\r\n" + 
				") where rn > ? and rn <= ? ";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (pageNum-1)*amount); 
			pstmt.setInt(2, pageNum * amount);	
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
			BbsVO vo = new BbsVO(rs.getInt("bno"),
					rs.getString("writer"),
					rs.getString("title"),
					rs.getString("content"),
					rs.getTimestamp("regdate"),
					rs.getInt("hit"));
			list.add(vo);
		}
				
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		        
		return list;
	}
	
	public	ArrayList<BbsVO> getListuser(String id) {
		ArrayList<BbsVO> list = new ArrayList<>();
		
		String sql = "select * from board b left outer join users u on u.id = b.writer where u.id = ?";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id); 
			
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
			BbsVO vo = new BbsVO(rs.getInt("bno"),
					rs.getString("writer"),
					rs.getString("title"),
					rs.getString("content"),
					rs.getTimestamp("regdate"),
					rs.getInt("hit"));
			list.add(vo);
		}
				
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		        
		return list;
	}
	public int getTotal( ) {
		int total = 0;
		
		String sql = "select count(*) as total from board";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				total = rs.getInt("total");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
		return total;
		
	}
	public void delete(String bno) {
		String sql = "delete from board where bno=?";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,bno);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
	}
	
	public	ArrayList<BbsVO> mainList() {
		ArrayList<BbsVO> list = new ArrayList<>();
		
		String sql = "select * from (select rownum rn ,bno,writer,title,content,regdate,hit from board order by bno desc) board where rn <6"; 
		
			
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			while(rs.next()) {
			BbsVO vo = new BbsVO(rs.getInt("bno"),
					rs.getString("writer"),
					rs.getString("title"),
					rs.getString("content"),
					rs.getTimestamp("regdate"),
					rs.getInt("hit"));
			list.add(vo);
		}
				
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		        
		return list;
	}
}
