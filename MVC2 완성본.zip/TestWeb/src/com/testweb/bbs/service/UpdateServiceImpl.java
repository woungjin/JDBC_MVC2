package com.testweb.bbs.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.coyote.RequestGroupInfo;

import com.testweb.bbs.model.BbsDAO;
import com.testweb.bbs.model.BbsVO;

public class UpdateServiceImpl implements BbsService {

	
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		String bno = request.getParameter("bno");
		String title = request.getParameter("title");
		String content = request.getParameter("content");

 
		
		BbsDAO dao = BbsDAO.getInstance();
		dao.update(bno,title,content);
		
		BbsVO vo = dao.getConent(bno);

		request.setAttribute("bbs", vo);
		
	}

}
